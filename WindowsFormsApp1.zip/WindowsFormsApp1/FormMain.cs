﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormMain : Form
    {
        //const string defaultIP = "172.0.0.1";
        //const string defaultPort = "12121";
        Socket socket = null;
        private static ArraySegment<byte> receiveBuffer;
        byte[] receiveBytes = new byte[1_024];
        private static ArraySegment<byte> sendBuffer;
        byte[] sendBytes;

        public FormMain(Socket socket)
        {
            InitializeComponent();
            this.socket = socket;
            ReceiveMessage();
        }

        private async void ReceiveMessage()
        {
            try
            {
                while (true)
                {
                    receiveBuffer = new ArraySegment<byte>(receiveBytes);
                    int receivedNum = await socket.ReceiveAsync(receiveBuffer, SocketFlags.None);
                    string msg = Encoding.UTF8.GetString(receiveBuffer.Array, 0, receivedNum);
                    if (receivedNum > 0) AppendText("<--  " + msg);
                    //sendBytes = Encoding.UTF8.GetBytes("<|ACK|>");
                    //_ = await socket.SendAsync(new ArraySegment<byte>(sendBytes), SocketFlags.None);
                }
            } catch (Exception) 
            {
                try
                {
                    AppendText("连接已断开");
                } catch (Exception) { }
            }
        }

        private async void SendMessage(object sender, EventArgs e)
        {
            sendBytes = Encoding.UTF8.GetBytes(textBoxMessage.Text);
            sendBuffer = new ArraySegment<byte>(sendBytes);
            _ = await socket.SendAsync(sendBuffer, SocketFlags.None);
            AppendText("-->  " + textBoxMessage.Text);
            textBoxMessage.ResetText();
        }

        private void AppendText(string text)
        {
            if (richTextBoxLog.Text.Length == 0) richTextBoxLog.Text = text;
            else richTextBoxLog.Text += '\n' + text;

            richTextBoxLog.SelectionStart = richTextBoxLog.TextLength;
            richTextBoxLog.ScrollToCaret();
        }

        private void FormMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Program.formStart != null && Program.formStart.Visible == false)
            {
                Program.formStart.Visible = true;
            }
            socket.Close();
        }
    }
}
